ATTACHED_FILES
--------------

Attach a list of files to a dashboard submission.

Set this property to a list of files that will be encoded and
submitted to the dashboard as an addition to the test result.
