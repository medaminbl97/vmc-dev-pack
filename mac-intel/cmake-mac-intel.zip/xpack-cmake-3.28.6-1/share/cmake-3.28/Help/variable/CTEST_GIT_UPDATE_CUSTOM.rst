CTEST_GIT_UPDATE_CUSTOM
-----------------------

.. versionadded:: 3.1

Specify the CTest ``GITUpdateCustom`` setting
in a :manual:`ctest(1)` dashboard client script.
