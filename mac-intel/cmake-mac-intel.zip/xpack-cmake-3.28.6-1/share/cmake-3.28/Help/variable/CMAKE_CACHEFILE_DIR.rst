CMAKE_CACHEFILE_DIR
-------------------

This variable is used internally by CMake, and may not be set during
the first configuration of a build tree.  When it is set, it has the
same value as :variable:`CMAKE_BINARY_DIR`.  Use that variable instead.
