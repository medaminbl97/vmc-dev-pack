CTEST_SUBMIT_INACTIVITY_TIMEOUT
-------------------------------

.. versionadded:: 3.23

Specify the CTest ``SubmitInactivityTimeout`` setting
in a :manual:`ctest(1)` dashboard client script.
