CMAKE_COMPILER_IS_GNUCC
-----------------------

True if the ``C`` compiler is GNU.

This variable is deprecated.  Use
:variable:`CMAKE_C_COMPILER_ID <CMAKE_<LANG>_COMPILER_ID>` instead.
