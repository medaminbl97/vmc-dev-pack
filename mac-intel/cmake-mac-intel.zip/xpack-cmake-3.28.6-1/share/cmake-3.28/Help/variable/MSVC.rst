MSVC
----

Set to ``true`` when the compiler is some version of Microsoft Visual C++
or another compiler simulating the Visual C++ ``cl`` command-line syntax.

See also the :variable:`MSVC_VERSION` variable.
