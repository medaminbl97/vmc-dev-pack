CMAKE_VS_DEBUGGER_WORKING_DIRECTORY
-----------------------------------

.. versionadded:: 3.27

This variable is used to initialize the :prop_tgt:`VS_DEBUGGER_WORKING_DIRECTORY`
property on each target as it is created.  See that target property
for additional information.
