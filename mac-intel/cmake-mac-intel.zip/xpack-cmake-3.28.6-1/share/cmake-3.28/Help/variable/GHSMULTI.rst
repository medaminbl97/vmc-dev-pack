GHSMULTI
--------

.. versionadded:: 3.3

``1`` when using :generator:`Green Hills MULTI` generator.

Also, Set to ``1`` when the target system is a Green Hills platform
(i.e. When :variable:`CMAKE_SYSTEM_NAME` is ``GHS-MULTI``).
