CMAKE_WINDOWS_EXPORT_ALL_SYMBOLS
--------------------------------

.. versionadded:: 3.4

Default value for :prop_tgt:`WINDOWS_EXPORT_ALL_SYMBOLS` target property.
This variable is used to initialize the property on each target as it is
created.
