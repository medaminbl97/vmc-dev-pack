CMAKE_VS_SDK_EXCLUDE_DIRECTORIES
--------------------------------

.. versionadded:: 3.12

This variable allows to override Visual Studio default Exclude Directories.
