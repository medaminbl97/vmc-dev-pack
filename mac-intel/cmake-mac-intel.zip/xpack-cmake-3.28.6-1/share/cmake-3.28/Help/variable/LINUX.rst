LINUX
-----

.. versionadded:: 3.25

Set to true when the target system is Linux.
