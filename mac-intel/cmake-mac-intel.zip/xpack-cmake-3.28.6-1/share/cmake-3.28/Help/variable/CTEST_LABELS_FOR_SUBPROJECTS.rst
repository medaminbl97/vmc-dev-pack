CTEST_LABELS_FOR_SUBPROJECTS
----------------------------

.. versionadded:: 3.10

Specify the CTest ``LabelsForSubprojects`` setting
in a :manual:`ctest(1)` dashboard client script.
