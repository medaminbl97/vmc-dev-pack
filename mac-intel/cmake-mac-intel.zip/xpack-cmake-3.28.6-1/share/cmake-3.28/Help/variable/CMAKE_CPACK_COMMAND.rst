CMAKE_CPACK_COMMAND
-------------------

.. versionadded:: 3.13

Full path to :manual:`cpack(1)` command installed with CMake.

This is the full path to the CPack executable :manual:`cpack(1)`
that can be used for custom commands or tests to invoke
CPack commands.
