VS_SHADER_FLAGS
---------------

.. versionadded:: 3.2

Set additional Visual Studio shader flags of a ``.hlsl`` source file.
