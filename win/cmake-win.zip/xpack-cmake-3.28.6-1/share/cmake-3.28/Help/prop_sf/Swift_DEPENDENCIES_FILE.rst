Swift_DEPENDENCIES_FILE
-----------------------

.. versionadded:: 3.15

This property sets the path for the Swift dependency file (swiftdeps) for the
source.  If one is not specified, it will default to ``<OBJECT>.swiftdeps``.
