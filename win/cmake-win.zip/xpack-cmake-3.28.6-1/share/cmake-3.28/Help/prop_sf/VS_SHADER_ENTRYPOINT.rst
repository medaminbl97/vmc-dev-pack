VS_SHADER_ENTRYPOINT
--------------------

.. versionadded:: 3.1

Specifies the name of the entry point for the shader of a ``.hlsl`` source
file.
