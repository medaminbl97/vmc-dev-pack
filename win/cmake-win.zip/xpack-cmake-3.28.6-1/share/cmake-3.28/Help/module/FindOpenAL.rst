.. cmake-module:: ../../Modules/FindOpenAL.cmake
