.. cmake-module:: ../../Modules/FindPhysFS.cmake
