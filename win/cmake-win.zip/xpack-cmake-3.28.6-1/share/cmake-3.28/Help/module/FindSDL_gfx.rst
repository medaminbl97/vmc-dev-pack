.. cmake-module:: ../../Modules/FindSDL_gfx.cmake
