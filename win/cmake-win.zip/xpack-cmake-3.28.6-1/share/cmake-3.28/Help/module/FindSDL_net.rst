.. cmake-module:: ../../Modules/FindSDL_net.cmake
